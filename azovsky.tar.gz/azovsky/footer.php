</div>
</div>

<div class="telph">
    <div class="container">
        <p class="uph">Не нашли то, что искали?</p>

        <p class="h">Оставьте заявку, и мы вам перезвоним!</p>

        <div class="obrph">
            <input type="text" name="name" placeholder="ваше имя">
            <input type="text" name="phn" placeholder="ваш телефон">
            <input type="submit" name="submit" value="Отправить">
        </div>
    </div>
</div>

<footer>

    <div class="container">

        <div class="col-md-4 col-sm-7 col-xs-12 nopadleft" style="padding-left:30px;">
            <h4>Навигация</h4>

            <div class="col-md-6 col-sm-6 col-xs-6" style="padding-left:0px;">
                <ul>
                    <li><a href="#" title="">&#9658; Главная</a></li>
                    <li><a href="#" title="">&#9658; Выбор пансионата</a></li>
                    <li><a href="#" title="">&#9658; Бронирование</a></li>
                    <li><a href="#" title="">&#9658; Оплата</a></li>
                    <li><a href="#" title="">&#9658; О нас</a></li>
                    <li><a href="#" title="">&#9658; Как купить</a></li>
                    <li><a href="#" title="">&#9658; Как добраться</a></li>
                    <li><a href="#" title="">&#9658; Блог</a></li>
                </ul>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-6">
                <ul>
                    <li><a href="#" title="">&#9658; Акции</a></li>
                    <li><a href="#" title="">&#9658; Спецпредложения</a></li>
                    <li><a href="#" title="">&#9658; Цены</a></li>
                    <li><a href="#" title="">&#9658; Фотогалереи</a></li>
                    <li><a href="#" title="">&#9658; Отдых с детьми</a></li>
                    <li><a href="#" title="">&#9658; SPA</a></li>
                    <li><a href="#" title="">&#9658; Спорт</a></li>
                    <li><a href="#" title="">&#9658; Экскурсии</a></li>
                </ul>
            </div>
        </div>
        <div class="col-md-3 col-sm-5 col-xs-12 nopadleft">
            <h4>Новости</h4>

            <div class="onenews">
                <div class="row">
                    <div class="col-md-4 col-sm-4 col-xs-4"
                         style="background:url(images/plane.jpg)no-repeat;background-size:contain;height:100px;"></div>
                    <div class="col-md-8 col-sm-8 col-xs-8">
                        <p class="title"><a href="#" title="Билеты в Крым">Билеты в Крым</a></p>

                        <p class="text">Снижение цен на авиабилеты в Крым в сентябре 2015 года</p>

                        <p class="data">12.03.2015</p>
                    </div>
                </div>
            </div>
            <div class="onenews">
                <div class="row">
                    <div class="col-md-4 col-sm-4 col-xs-4"
                         style="background:url(images/plane.jpg)no-repeat;background-size:contain;height:100px;"></div>
                    <div class="col-md-8 col-sm-8 col-xs-8">
                        <p class="title"><a href="#" title="Билеты в Крым">Билеты в Крым</a></p>

                        <p class="text">Снижение цен на авиабилеты в Крым в сентябре 2015 года</p>

                        <p class="data">12.03.2015</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-sm-7 col-xs-12 nopadleft" style="padding-left:0px;">
            <h4>Подписка</h4>

            <p class="onlyinfo">Подпишитесь на новости, чтобы всегда быть в курсе наших акций и предложений</p>
            <input type="text" id="rscbottom">

            <p class="onlyinfo">Рассылка не чаще 2 раз в месяц</p>

        </div>
        <div class="col-md-3 col-sm-5 col-xs-12 nopadleft">
            <h4>О нас</h4>

            <p class="onlyinfo">Отдых в пансионате "Азовский" идеален для восстановления здоровья и душевных сил, нового
                заряда бодрости, для солнечных впечатлений и радостных эмоций всей семьи.</p>

            <p class="phone footTitle"><img src="images/phone.png">&nbsp;8-800-775-15-41</p>

            <p class="footMail"><a href="mailto:mail@azovsky.ru">mail@azovsky.ru</a></p>

            <div class="social">
                <ul>
                    <li><a href="#"><img src="images/vk.png"></a></li>
                    <li><a href="#"><img src="images/fb.png"></a></li>
                    <li><a href="#"><img src="images/ok.png"></a></li>
                    <li><a href="#"><img src="images/yt.png"></a></li>
                    <li><a href="#"><img src="images/gp.png"></a></li>
                    <li><a href="#"><img src="images/mr.png"></a></li>
                    <div class="clear"></div>
                </ul>
            </div>
        </div>

    </div>
</footer>

<script>
    $('.fancybox').fancybox();
</script>

<div class="subfooter">
    <div class="container">
        <div class="col-md-3 col-sm-4 col-xs-6">
            <a href="#"><img src="images/logob.png"></a>
        </div>
        <div class="col-md-9 col-sm-8 col-xs-6 text-right">
            2015 Azovsky <a href="#"> <img src="images/strtp.png" class="top"></a>
        </div>
    </div>
</div>

</body>