<?php

require 'header.php';

echo "Hello";

require 'footer.php';



