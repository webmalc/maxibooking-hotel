<?php

require 'header.php';
$url = 'http://mbh.h/app_dev.php/online_booking?'. $_SERVER['QUERY_STRING'];

$html = file_get_contents($url);
?>

<?php echo $html; ?>
<?php require 'footer.php';
