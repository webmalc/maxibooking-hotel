<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans&subset=latin,cyrillic' rel='stylesheet'
          type='text/css'>
    <title>Результаты поиска</title>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/locale/ru.js"></script>

    <script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" />

    <link href="css/searchstyle.css" rel="stylesheet">
</head>

<body>

<header>

    <div class="container">

        <div class="col-md-3 col-sm-12 col-xs-12 logo"><a href="#"><img src="images/logo.png"></a></div>
        <div class="col-md-9 col-sm-12 col-xs-12">
            <div class="row infohd">
                <div class="col-md-5 col-sm-7 col-xs-7" style="padding-right:0px;">для регионов (звонок
                    бесплатный)<br><span>8 (800) 555-10-17 	8 (800) 775-15-41</span></div>
                <div class="col-md-4 zaiav">оставьте заявку и мы перезвоним<br><a href="#"
                                                                                  title="Заказ обратного звонка"><span>свяжитесь со мной</span></a>
                </div>
                <div class="col-md-3 col-sm-5 col-xs-5">пишите нам<br><a href="#" title="Наш Имейл"><span>mail@azovski.ru</span></a>
                </div>
            </div>
            <div class="row">
                <nav class="col-md-12 text-right">
                    <ul>
                        <a href="#" title="Главная">
                            <li>Главная <img src="images/str.png" alt=""></li>
                        </a>
                        <a href="#" title="Выбор пансионата">
                            <li>Выбор пансионата <img src="images/str.png" alt=""></li>
                        </a>
                        <a href="#" title="Как купить">
                            <li>Как купить <img src="images/str.png" alt=""></li>
                        </a>
                        <a href="#" title="Как добраться">
                            <li>Как добраться <img src="images/str.png" alt=""></li>
                        </a>
                        <a href="#" title="Контакты">
                            <li>Контакты <img src="images/str.png" alt=""></li>
                        </a>

                        <div class="clear"></div>
                    </ul>
                </nav>
            </div>
        </div>

    </div>

</header>

<div class="breads">
    <div class="container">
        <div class="col-md-2 col-sm-5 col-xs-5"><p>Галерея</p></div>
        <div class="col-md-10 col-sm-7 col-xs-7 text-right"><a href="#" title="Главная">Главная</a> / <a href="#"
                                                                                                         title="Страницы">Страницы</a>
            / <a href="#" title="Азовский">Азовский</a> / <span>Галерея</span></div>
    </div>
</div>

<div class="container minpadtop">
    <div class="col-md-3">
        <div class="bronirovanie">
            <h2>Рассчитать стоимость</h2>
            <?php echo file_get_contents('http://mbh.h/app_dev.php/online_booking/form?' . $_SERVER['QUERY_STRING']); ?>

        </div>
    </div>
    <div class="col-md-9">


