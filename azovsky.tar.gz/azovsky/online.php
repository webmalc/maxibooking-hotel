<head>
	<title>
	</title>
</head>
<body>

<div id="mbh-form-wrapper" style="overflow: hidden; width: 300px; height: auto;"><a href="http://maxi-booking.ru/">система онлайн бронирования</a></div>

<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css"><div id="mbh-results-wrapper" style="overflow: hidden; width: auto; height: auto;"></div>

<script>window.jQuery || document.write('<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"><\/script>')</script><script>$.isFunction($().select2) || document.write('<script src="//cdnjs.cloudflare.com/ajax/libs/select2/3.5.0/select2.min.js"><\/script><link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/select2/3.5.0/select2.css"/>')</script><script>$.isFunction($().mask) || document.write('<script src="//cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.3.1/jquery.maskedinput.min.js"><\/script>')</script><script>$.isFunction($().cookie) || document.write('<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"><\/script>')</script><script type="text/javascript" src="http://mbh.h/app_dev.php/management/online/api/results"></script>

<script>window.jQuery || document.write('<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"><\/script>')</script><script>$.isFunction($().datepicker) || document.write('<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.1/jquery-ui.min.js"><\/script><link rel="stylesheet" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.1/themes/smoothness/jquery-ui.css"/>')</script><script type="text/javascript" src="http://mbh.h/app_dev.php/management/online/api/form?locale=ru"></script>


</body>
